package com.example.dama.Controller;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

import com.example.Design.R;


public class ServiceUtils extends Service implements MediaPlayer.OnCompletionListener {
    public ServiceUtils() {
        Log.d("MyService", "Constructor");
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.d("MyService", "OnCreate");
        // we will add a notification here later
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("MyService", "onStartCommand");
        int retVal = super.onStartCommand(intent, flags, startId);
        Toast.makeText(this, "Service starting", Toast.LENGTH_SHORT).show();
        MediaPlayer mp = MediaPlayer.create(this, R.raw.gudok);
        //Globals.mPlayer = mp;
        mp.setOnCompletionListener(this);
        mp.start();
        // Notification
        //String notiTitle = "This is a notification for you";
        //String notiText = "Click here to open Activity2";
        //Intent intent2 = new Intent(this, Activity2.class);
        //Globals.makeNotification(this, intent2, notiTitle, notiText);
        return retVal;
    }

    @Override
    public void onDestroy() {
        Log.d("MyService", "onDestroy");
        //Globals.mPlayer = null; // this must be done to prevent a memory leak
        super.onDestroy();
    }

    @Override
    public void onCompletion(MediaPlayer mp) {
        Log.d("MyService", "MediaPlayer-OnCompletion");
        stopSelf(); //  the service will destroy itself once the media stops playing
    }
}

