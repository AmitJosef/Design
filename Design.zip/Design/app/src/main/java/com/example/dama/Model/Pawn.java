package com.example.dama.Model;
import com.example.dama.Controller.Player;

public class Pawn extends Piece {
    public Pawn(Player player, Position position) {
        super(player, position);
    }

    @Override
    public void execMove(Position to) {
        this.setPosition(to);
    }

    @Override
    public boolean isAQueen(){return false;}
}
