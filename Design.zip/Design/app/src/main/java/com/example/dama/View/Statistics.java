package com.example.dama.View;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.Design.R;
import com.example.dama.Controller.MenuUtils;
import com.example.dama.Controller.PrefsUtils;
import com.example.dama.Controller.User;

import java.util.ArrayList;
import java.util.Comparator;

public class Statistics extends AppCompatActivity
        implements AdapterView.OnItemClickListener,
        AdapterView.OnItemLongClickListener,
        AdapterView.OnItemSelectedListener

{

    ListView users_lv;
    ArrayList<User> orgData;
    ArrayList<String> data;
    TextView selectedTv;
    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.statistics);

        data = new ArrayList<String>();
        orgData = PrefsUtils.readPersonsList(this);
        if (orgData == null) {
            orgData = new ArrayList<User>();
            User def1 = new User("DEFAULT1", "1234");
            orgData.add(def1);
            User def2 = new User("DEFAULT2", "1234");
            orgData.add(def2);
            PrefsUtils.writePersonsList(orgData, Statistics.this);
        }

        sortAL(orgData);
        //sort orgData
        //after that we could do that if u click pn player it opens dialog and shows his stats and place
        users_lv = findViewById(R.id.users_stats);
        selectedTv = findViewById(R.id.tv_player_stats);

        for (int i = 0; i < orgData.size(); i++) {
            data.add(orgData.get(i).showAllStats());
        }

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_item, R.id.tv_list_item, data);

        users_lv.setAdapter(adapter);
        users_lv.setOnItemClickListener(this);
        users_lv.setOnItemLongClickListener(this);

        selectedTv.setText("");
    }

    public void onClick(View v){
        Intent intent = new Intent(this, MainScreen.class);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (MenuUtils.handleMenu(item, this))
            return true;
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int pos, long id) {
        selectedTv.setText(orgData.get(pos).showAllStats());
        Log.d("stats", this.orgData.get(pos).showAllStats());
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> adapterView, View view, int pos, long id) {
        Toast.makeText(this, orgData.get(pos).showAllStats(), Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int pos, long id) {
        selectedTv.setText(orgData.get(pos).showAllStats());
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


    @RequiresApi(api = Build.VERSION_CODES.N)
    public static void sortAL(ArrayList<User> users) {
        Comparator<User> winsComparator = (User u1, User u2) ->
        {
            if (u2.getWins() - u1.getWins() == 0) {
                return (int) u2.getWinsPercent() - (int) u1.getWinsPercent();
            }
            return u2.getWins() - u1.getWins();
        };
        users.sort(winsComparator);
    }
}

