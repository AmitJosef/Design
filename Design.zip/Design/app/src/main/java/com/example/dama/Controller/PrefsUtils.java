package com.example.dama.Controller;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class PrefsUtils
{
    public static final String UserKey = "Users";
    public static final String PrefName = "MyPref";

    public static void writePersonsList(ArrayList<User> persons, Context context)
    {
        SharedPreferences pref;
        SharedPreferences.Editor editor;

        pref = context.getSharedPreferences(PrefName, 0);
        editor = pref.edit();
        // Convert arrayList to Json
        Gson gson = new Gson();
        String json = gson.toJson(persons);
        Log.d("WritePersonsList", json);
        // Save it to prefs
        editor.putString(UserKey, json);
        editor.commit();
    }

    public static ArrayList<User> readPersonsList(Context context)
    {
        SharedPreferences pref;

        pref = context.getSharedPreferences(PrefName, 0);

        Gson gson = new Gson();
        // Read json string from prefs
        String jsonStr = pref.getString(UserKey, "");
        // Build the TypeToken for parsing  ArrayList<Person>
        Type arraylistType = new TypeToken<ArrayList<User>>(){}.getType();
        ArrayList<User> personArrList = new ArrayList<User>(); // will store read data

        try
        {
            personArrList = gson.fromJson(jsonStr, arraylistType);
        }
        catch (Exception e)
        {
            Log.e("ReadJsonArrayList", "Error decoding json: " + jsonStr);
            e.printStackTrace();
            return null;
        }
        return personArrList;
    }

}