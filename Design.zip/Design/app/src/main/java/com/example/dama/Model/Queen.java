package com.example.dama.Model;
import com.example.dama.Controller.Player;

public class Queen extends Piece {

    public Queen(Player player, Position position){
        super(player, position);
    }
    public Queen(Piece piece){
        super(piece);
    }

    @Override
    public void execMove(Position to) {
        this.setPosition(to);
    }

    @Override
    public boolean isAQueen(){return true;}

}
