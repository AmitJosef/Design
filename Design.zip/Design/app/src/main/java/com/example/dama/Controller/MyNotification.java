package com.example.dama.Controller;

import androidx.appcompat.app.AppCompatActivity;;
import android.os.Bundle;
import com.example.Design.R;

public class MyNotification extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.reminder);
    }
}