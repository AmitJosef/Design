package com.example.dama.Controller;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.ImageView;

import androidx.annotation.NonNull;

import com.example.dama.Model.Board;
import com.example.dama.Model.Pawn;
import com.example.dama.Model.Piece;
import com.example.dama.Model.Position;
import com.example.dama.Model.Queen;
import com.example.dama.View.GameBoard;
import com.example.dama.View.Registration;
import com.example.dama.View.Statistics;

import java.util.ArrayList;

public class GameManager {
    public GameBoard gameUI;
    private Board board;
    private Player[] players = new Player[2];
    Piece selectedPiece;
    Action action;
    GameStatus gameStatus;


    //init players  with players gotten from gameboard, which were passed by intents from registration
    public GameManager(@NonNull GameBoard gameUI){
        ArrayList <User> userArrayList = new ArrayList<>();
        this.gameUI = gameUI;
        this.action = Action.FirstClick;
        this.players[0] = new Player(this.gameUI.getUser1(), "white");
        this.players[1] = new Player(this.gameUI.getUser2(), "black");
        this.players[0].getUser().addGame();
        this.players[1].getUser().addGame();
        gameStatus = GameStatus.PLAYING;
        initGame();
        for (int i = 0; i < this.gameUI.getUserArrayList().size(); i++) {
            if (this.players[0].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[0].getUser());
            }
            else if (this.players[1].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[1].getUser());
            }
            else {
                userArrayList.add(this.gameUI.getUserArrayList().get(i));
            }
        }
        PrefsUtils.writePersonsList(userArrayList, this.gameUI);
    }

    public void initGame(){
        this.board = new Board();
        this.gameUI.initBoard();
    }

    public void firstClick(@NonNull Position position){
        Piece piece = this.board.getPiece(position);
        if (this.board.isPieceSelectable(piece)){
            markPossibleMoves(piece);
            this.selectedPiece = this.board.getPiece(position);
            this.action = Action.SecondClick;
            updateCommandBar("CLICK ON ONE OF THE MARKED TILES TO MOVE.");
        }
        else {
            updateCommandBar("THIS CAN'T BE SELECTED.");
        }
    }

    public void cancelSelection(@NonNull Position position) {
        if (this.board.isCellEmpty(position)) {
            return;
        }
        this.gameUI.cancelMarking(position);
        ArrayList<Position> possibilities = this.board.legalPositions(this.board.getPiece(position));
        for (int i = 0; i < possibilities.size(); i++) {
            this.gameUI.cancelMarking(possibilities.get(i));
        }
        this.selectedPiece = null;
        this.action = Action.FirstClick;
    }

    public void secondClick(@NonNull Piece piece, @NonNull Position position){
        ArrayList<Position> possibilities = this.board.legalPositions(piece);
        for (int i = 0; i < possibilities.size(); i++) {
            if (possibilities.get(i).equals(position)) {
                execAction(piece, position);
                return;
            }
        }
        cancelSelection(piece.getPosition());
    }

    public Board getBoard() {
        return board;
    }

    public void execAction(@NonNull Piece piece, @NonNull Position moveTo){
        updateCommandBar("");
        int orgRow = piece.getPosition().getRow(), orgCol = piece.getPosition().getCol();
        this.gameUI.removePiece(piece.getPosition());
        boolean eat = false;
        int r = moveTo.getRow(), c  = moveTo.getCol();
        ArrayList<Position> eaten = this.board.legalEats2(piece)[0];

        if (c > orgCol) {
            for (int i = 0; i < eaten.size(); i++) {
                if (eaten.get(i).getCol() > orgCol) {
                    this.board.removePiece(this.board.getPiece(eaten.get(i)));
                    this.gameUI.removePiece(eaten.get(i));
                    eat = true;
                    break;
                }
            }
        }
        else if (c < orgCol) {
            for (int i = 0; i < eaten.size(); i++) {
                if (eaten.get(i).getCol() < orgCol) {
                    this.board.removePiece(this.board.getPiece(eaten.get(i)));
                    this.gameUI.removePiece(eaten.get(i));
                    eat = true;
                    break;
                }
            }
        }

        else if (r > orgRow) {
            for (int i = 0; i < eaten.size(); i++) {
                if (eaten.get(i).getRow() > orgRow) {
                    this.board.removePiece(this.board.getPiece(eaten.get(i)));
                    this.gameUI.removePiece(eaten.get(i));
                    eat = true;
                    break;
                }
            }
        }

        else if (r < orgRow) {
            for (int i = 0; i < eaten.size(); i++) {
                if (eaten.get(i).getRow() < orgRow) {
                    this.board.removePiece(this.board.getPiece(eaten.get(i)));
                    this.gameUI.removePiece(eaten.get(i));
                    eat = true;
                    break;
                }
            }
        }

        piece.execMove(moveTo);

        if(((piece.getPlayer().getColor().equalsIgnoreCase("white") && moveTo.getRow() == 0) || (piece.getPlayer().getColor().equalsIgnoreCase("black") && moveTo.getRow() == 7)) && piece instanceof Pawn) {
            Log.d("q", "make");
            this.board.makeQueen((Pawn)piece, moveTo);
            this.gameUI.makeQueen((Pawn)piece);
            piece = new Queen(piece);
            Log.d("piece", piece.toString());
            Log.d("q", "made");
        }

        this.board.getBoard()[orgRow][orgCol] = null;
        this.board.getBoard()[moveTo.getRow()][moveTo.getCol()] = piece;
        this.gameUI.pieceExecAction(piece, moveTo);
        if (eat && !this.board.legalEats2(this.selectedPiece)[0].isEmpty()) {
            this.cleanSelection();
            updateCommandBar("CONTINUE EATING");
            return;
        }
        else {
            this.action = Action.FirstClick;
            this.selectedPiece = null;
            this.changeTurn();
        }
        this.cleanSelection();
    }

    public void markPossibleMoves(@NonNull Piece piece){
        this.gameUI.markPossiblePositions(piece.getPosition());
        ArrayList<Position> possibilities = this.board.legalPositions(this.board.getPiece(piece.getPosition()));
        for (int i = 0; i < possibilities.size(); i++) {
            this.gameUI.markPossiblePositions(possibilities.get(i));
        }
        return;
    }

    public boolean checkDraw() {
        ArrayList <User> userArrayList = new ArrayList<>();
        if (this.board.checkDraw()) {
            gameStatus = GameStatus.DRAW;
            updateTurnBar("IT'S A DRAW");
            this.players[0].getUser().addDraw();
            this.players[1].getUser().addDraw();
            disableAllButtons();
        for (int i = 0; i < this.gameUI.getUserArrayList().size(); i++) {
            if (this.players[0].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[0].getUser());
            } else if (this.players[1].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[1].getUser());
            } else {
                userArrayList.add(this.gameUI.getUserArrayList().get(i));
            }
        }
            PrefsUtils.writePersonsList(userArrayList, this.gameUI);
        }
        return this.board.checkDraw();
    }

    public Player checkWin() {
        int l = -1;
        ArrayList <User> userArrayList = new ArrayList<>();
        int w = this.board.winner();
        if (w == -1) {
            return null;
        }
        gameStatus = GameStatus.WIN;
        updateTurnBar(this.players[w].getUser().getName().toUpperCase() + " WON!!!");
        disableAllButtons();
        this.players[w].getUser().addWin();

        if (w == 1) {
            this.players[0].getUser().addLose();
            l = 0;
        }
        if (w == 0){
            this.players[1].getUser().addLose();
            l = 1;
        }

        for (int i = 0; i < this.gameUI.getUserArrayList().size(); i++) {
            if (this.players[w].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[w].getUser());
            }
            else if (this.players[l].getUser().equals(this.gameUI.getUserArrayList().get(i))) {
                userArrayList.add(this.players[l].getUser());
            }
            else {
                userArrayList.add(this.gameUI.getUserArrayList().get(i));
            }
        }
        PrefsUtils.writePersonsList(userArrayList, this.gameUI);

        //ADD ANIMATION BY COLOR
        return this.players[w];
    }

    public void updateTurnBar(String message){
        this.gameUI.getTurnBar().setText(message);
    }

    public void updateCommandBar(String message){
        this.gameUI.getCommandBar().setText(message);
    }


    public Action getAction() {
        return action;
    }

    public GameStatus getGameStatus() {
        return gameStatus;
    }

    public Piece getSelectedPiece() {return selectedPiece;}

    private void changeTurn() {
        this.board.changeTurn();
        int turn = this.board.getTurn();
        String name = players[turn].getUser().getName().toUpperCase().concat("'S TURN");
        this.updateTurnBar(name);
    }

    private void cleanSelection() {
        for (int i = 0; i < this.board.getBoard().length; i++) {
            for (int j = 0; j < this.board.getBoard()[i].length; j++) {
                if (this.board.isCellEmpty(new Position(i,j))) {
                    this.gameUI.removePiece(new Position(i,j));
                }
            }
        }
    }


    private void disableAllButtons() {
        for (int i = 0; i < this.board.getBoard().length; i++) {
            for (int j = 0; j < this.board.getBoard()[i].length; j++) {
                this.gameUI.getBoard()[i][j].setClickable(false);
            }
        }
    }
}