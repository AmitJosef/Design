package com.example.dama.Controller;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Vibrator;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.Design.R;
import com.example.dama.View.MainScreen;
import com.example.dama.View.Options;
import com.example.dama.View.Registration;

import java.util.ArrayList;
import java.util.Calendar;

public class MenuUtils {

    Vibrator vbr;
    private int year, month, day, hour, minute, second = 0;
    private Calendar c;
    private Activity activity;
    private ArrayList<User> usersAL;
    private EditText newUserName, newUserPassword;
    private String reminder = "hey";

    public void setActivity(Activity activity) {
        this.activity = activity;
    }
    public Activity getActivity() {
        return activity;
    }

    //Menu Handling - start
    public static boolean handleMenu(MenuItem item, Activity activity) {
        MenuUtils menuUtils = new MenuUtils();
        menuUtils.setActivity(activity);
        menuUtils.usersAL = PrefsUtils.readPersonsList(activity);
        int resID = item.getItemId();
        switch (resID) {
            case R.id.menu_options:
                menuUtils.showOptionsDialog(activity);
                return true;

            case R.id.menu_exit:
                menuUtils.showExitDialog(activity);
                return true;

            default:
                return false;
        }
    }

    private class CustomDialogClickListener implements View.OnClickListener {
        Dialog dialog;

        public CustomDialogClickListener(Dialog _dialog) {
            this.dialog = _dialog;
        }

        @Override
        public void onClick(View v) {
            int id = v.getId();
            if (id == R.id.btn_okRls || id == R.id.btn_okStat || id == R.id.btn_okSet || id == R.id.btn_cancel_creation || id == R.id.btn_gotIt)
                dialog.dismiss();

            switch (id) {
                case R.id.btm_o:
                    activity.startActivity(new Intent(activity, MainScreen.class));
                    return;

                case R.id.to_rules:
                    showRulesDialog(activity);
                    return;

                case R.id.to_stats:
                    showStatisticsDialog(activity);
                    return;

                case R.id.btn_save_game_status:
                    Toast.makeText(activity, "SAVED", Toast.LENGTH_SHORT).show();
                    activity.startActivity(new Intent(activity, MainScreen.class));
                    return;

                case R.id.cnu_o:
                    showCreateNewUserDialog();
                    return;

                case R.id.btn_createNewAlarm:
                    showAlarmDialog();
                    //setFutureAlarm(c.getTimeInMillis());
                    return;

                case R.id.btn_finish:
                    User user = new User(newUserName.getText().toString(), newUserPassword.getText().toString());
                    for (int i = 0; i < usersAL.size(); i++) {
                        if (user.getName().equalsIgnoreCase(usersAL.get(i).getName())) {
                            Toast.makeText(activity, "USERNAME IS UNAVAILABLE", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                    usersAL.add(user);
                    PrefsUtils.writePersonsList(usersAL, activity);
                    dialog.dismiss();
                    return;

                default:
                    return;
            }



            /*
            if (id == R.id.sound_oo) {
               if (View.OnClick)
                    Toast.makeText(Registration.this, "SOUND ON", Toast.LENGTH_SHORT).show();

                    Toast.makeText(Registration.this, "SOUND OFF", Toast.LENGTH_SHORT).show();
            }
            }*/
        }
    }


    //MENU - QUIT
    private void showExitDialog(Activity activity) {
        new AlertDialog.Builder(activity)
                .setMessage("ARE YOU SURE YOU WANT TO EXIT?")
                .setCancelable(false)
                .setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        activity.finishAffinity();
                    }
                })
                .setNegativeButton("NO", null).show();
    }


    //MENU - RULES
    void showRulesDialog(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.rules);
        Button ok = dialog.findViewById(R.id.btn_okRls);
        MenuUtils.CustomDialogClickListener dcl = new MenuUtils.CustomDialogClickListener(dialog);
        ok.setOnClickListener(dcl);
        dialog.show();
    }

    //MENU - STATISTICS
    private void showStatisticsDialog(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.statistics);
        Button ok = dialog.findViewById(R.id.btn_okStat);
        MenuUtils.CustomDialogClickListener dcl = new MenuUtils.CustomDialogClickListener(dialog);
        ok.setOnClickListener(dcl);
        dialog.show();
    }

    //MENU - SETTINGS
    private void showOptionsDialog(Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.options);
        Switch sound = dialog.findViewById(R.id.swc_sound);
        Button ok = dialog.findViewById(R.id.btn_okSet);
        Button rules = dialog.findViewById(R.id.to_rules);
        Button stats = dialog.findViewById(R.id.to_stats);
        Button cnu = dialog.findViewById(R.id.cnu_o);
        Button btms = dialog.findViewById(R.id.btm_o);
        Button cna = dialog.findViewById(R.id.btn_createNewAlarm);
        Button sgs = dialog.findViewById(R.id.btn_save_game_status);
        MenuUtils.CustomDialogClickListener dcl = new MenuUtils.CustomDialogClickListener(dialog);
        ok.setOnClickListener(dcl);
        rules.setOnClickListener(dcl);
        stats.setOnClickListener(dcl);
        cnu.setOnClickListener(dcl);
        btms.setOnClickListener(dcl);
        cna.setOnClickListener(dcl);
        sgs.setOnClickListener(dcl);
        sound.setOnClickListener(dcl);
        dialog.show();
    }


    // ALARM MANAGER:
    public void setFutureAlarm(long timeInMillis)
    {
        Intent after = new Intent(this.getActivity(), ServiceUtils.class);
        PendingIntent afterIntent = PendingIntent.getService(this.getActivity(), 0, after, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alMgr = (AlarmManager) this.activity.getSystemService(Context.ALARM_SERVICE);
        alMgr.set(AlarmManager.RTC_WAKEUP, timeInMillis, afterIntent);
    }

    public void showAlarmDialog()
    {
        Toast.makeText(this.getActivity(), "alarm at set time", Toast.LENGTH_LONG).show();
        c = Calendar.getInstance();
        Log.d("hey", "inAD");
        takeMonthDay();

    }
    private void TakeHourMinute() {
        AlertDialog.Builder adb = new AlertDialog.Builder(this.getActivity());
        adb.setTitle("Choose month and day");
        TimePicker tp = new TimePicker(this.getActivity());
        tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                hour=i;
                minute=i1;
            }
        });
        adb.setView(tp);
        adb.setPositiveButton("Set Alarm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        c.set(year, month - 1,day,hour,minute, second);
                        String s = "" + year + "/" + month+ "/" + day + ":" + hour + ":" + minute + ":" + second;
                        //tvTime.setText(s);
                        setFutureAlarm(c.getTimeInMillis());
                    }
                });
        adb.create().show();

    }


    // a nested class that implements the DateSetListener Interface
    private class MyDateSetListener implements DatePickerDialog.OnDateSetListener
    {
        @Override
        public void onDateSet(DatePicker view, int y, int m, int d)
        {
            // String msg = String.format("Selected date is %s/%s/%s", d, 1 + m, y);
            year = y;
            month = m + 1;
            day = d;
            TakeHourMinute();
        }
    } // private class MyDateSetListener

    private void takeMonthDay() {
        DatePickerDialog.OnDateSetListener listener = new MyDateSetListener();  // see class implementation below

        DatePickerDialog dpd = new DatePickerDialog(this.getActivity(),listener,2023, 2 - 1, 10);
        dpd.setTitle("Choose month and day");
        dpd.show();
    }


    public void notification()
    {
        String notiTitle = "REMINDER";
        String notiText ="CLICK HERE TO OPEN REMINDER";

        Intent intent = new Intent(this.activity, MyNotification.class);
        //show dialog here instead
        showReminderDialog();
        makeNotification(this.getActivity(), intent, notiTitle, notiText);
    }

    public void makeNotification(Context context, Intent intent, String notiTitle, String notiText)
    {
        NotificationManager mNotificationManager;
        String id = "my_channel_01";
        int importance = NotificationManager.IMPORTANCE_LOW;
        NotificationChannel mChannel;

        // Set notification channel
        mNotificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
        {

            mChannel = new NotificationChannel(id, "channel Name", importance);
            mChannel.enableLights(true);
            mNotificationManager.createNotificationChannel(mChannel);
        }

        Intent notifyIntent = new Intent(context, this.activity.getClass());
        notifyIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent contentIntent = PendingIntent.getActivity(context,0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder builder = new Notification.Builder(context);

        builder.setContentIntent(contentIntent);
        builder.setSmallIcon(R.drawable.bbq);
        builder.setContentTitle(notiTitle);
        builder.setContentText(notiText);
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setWhen(System.currentTimeMillis());
        builder.setLargeIcon(BitmapFactory.decodeResource(context.getResources(), R.drawable.bbq));
        builder.setDefaults(Notification.DEFAULT_LIGHTS);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            builder.setChannelId(id); // Channel

        Notification noti = builder.build();

        NotificationManager notificationManager=
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(1, noti);
    }


    //reminder dialog
    public void showReminderDialog()
    {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.reminder);
        TextView reminder1 = dialog.findViewById(R.id.tv_reminder);
        reminder1.setText(this.reminder);
        Button gI = dialog.findViewById(R.id.btn_gotIt);
        CustomDialogClickListener dcl = new CustomDialogClickListener(dialog);
        gI.setOnClickListener(dcl);
        dialog.show();
    }

    //cnu
    public void showCreateNewUserDialog()
    {
        final Dialog dialog = new Dialog(activity);
        dialog.setContentView(R.layout.create_new_user);
        newUserName = dialog.findViewById(R.id.et_enter_name);
        newUserPassword = dialog.findViewById(R.id.et_password);
        Button finish = dialog.findViewById(R.id.btn_finish);
        Button cancel = dialog.findViewById(R.id.btn_cancel_creation);
        CustomDialogClickListener dcl = new CustomDialogClickListener(dialog);
        finish.setOnClickListener(dcl);
        cancel.setOnClickListener(dcl);
        dialog.show();
    }
}
