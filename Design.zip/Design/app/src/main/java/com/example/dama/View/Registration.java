package com.example.dama.View;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.Design.R;
import com.example.dama.Controller.MenuUtils;
import com.example.dama.Controller.PrefsUtils;
import com.example.dama.Controller.User;

import java.util.ArrayList;


public class Registration extends AppCompatActivity {
    Spinner spinnerU, spinnerD;
    ArrayList<User> usersAL;
    EditText newUserName, newUserPassword;
    int p1Index, p2Index;
    String p1Name, p2Name;
    User def1 = new User("DEFAULT1", "1234"), def2 = new User("DEFAULT2", "1234");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registration);
        usersAL = PrefsUtils.readPersonsList(this);
        if (usersAL == null) {
            usersAL = new ArrayList<User>();
            usersAL.add(def1);
            usersAL.add(def2);
            PrefsUtils.writePersonsList(usersAL, Registration.this);
        }
        spinner1();
        spinner2();
    }


    public void spinner1() {
        spinnerU = findViewById(R.id.spnr_u1);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, usersAL);
        spinnerU.setAdapter(adapter);
        spinnerU.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(Registration.this, ""+adapterView.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                p1Name = ""+adapterView.getSelectedItem();
            }
            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void spinner2() {
        spinnerD = findViewById(R.id.spnr_u2);
        ArrayAdapter adapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, usersAL);
        spinnerD.setAdapter(adapter);
        spinnerD.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                Toast.makeText(Registration.this, ""+adapterView.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
                p2Name = ""+adapterView.getSelectedItem();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }
    
    public void onClickCB(View v) {
        CheckBox f1 = findViewById(R.id.cb_finish1);
        CheckBox f2 = findViewById(R.id.cb_finish2);
        CheckBox cb = (CheckBox) v;
        if(p1Name.equalsIgnoreCase(p2Name)) {
            cb.setChecked(false);
            Toast.makeText(Registration.this, "CAN'T START A GAME WITH SAME USERS", Toast.LENGTH_SHORT).show();
            return;
        }
        if (f1.isChecked() && f2.isChecked()) {
            Intent intent = new Intent(this, GameBoard.class);
            p1Index = spinnerU.getSelectedItemPosition();
            p2Index = spinnerD.getSelectedItemPosition();
            intent.putExtra("index1", p1Index);
            intent.putExtra("index2", p2Index);
            startActivity(intent);
            finish();
        }
    }



        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            if (MenuUtils.handleMenu(item, this))
                return true;
            return super.onOptionsItemSelected(item);
        }

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            super.onCreateOptionsMenu(menu);
            MenuInflater menuInflater = getMenuInflater();
            menuInflater.inflate(R.menu.menu, menu);
            return true;
        }




    public void createNewUserClick(View view){
        showCreateNewUserDialog();
    }

    public void showCreateNewUserDialog()
    {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.create_new_user);
        newUserName = dialog.findViewById(R.id.et_enter_name);
        newUserPassword = dialog.findViewById(R.id.et_password);
        Button finish = dialog.findViewById(R.id.btn_finish);
        Button cancel = dialog.findViewById(R.id.btn_cancel_creation);
        CustomDialogClickListener dcl = new CustomDialogClickListener(dialog);
        finish.setOnClickListener(dcl);
        cancel.setOnClickListener(dcl);
        dialog.show();
    }

    private class CustomDialogClickListener implements View.OnClickListener {
        Dialog dialog;

        public CustomDialogClickListener(Dialog _dialog) {
            this.dialog = _dialog;
            dialog.dismiss();
        }

        @Override
        public void onClick(View v) {
            if (v.getId() == R.id.btn_cancel_creation) {
                dialog.dismiss();
                return;
            }
            User user = new User(newUserName.getText().toString(), newUserPassword.getText().toString());
            for (int i = 0; i < usersAL.size(); i++) {
                if (user.getName().equalsIgnoreCase(usersAL.get(i).getName())) {
                    Toast.makeText(Registration.this, "USERNAME IS UNAVAILABLE", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
            usersAL.add(user);
            PrefsUtils.writePersonsList(usersAL, Registration.this);
            dialog.dismiss();
        }
    }
}

