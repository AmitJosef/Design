package com.example.dama.Controller;

public enum GameStatus {
    PLAYING,
    WIN,
    DRAW;
}
