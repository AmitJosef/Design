package com.example.dama.View;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import com.example.Design.R;
import com.example.dama.Controller.Action;
import com.example.dama.Controller.GameManager;
import com.example.dama.Controller.GameStatus;
import com.example.dama.Controller.MenuUtils;
import com.example.dama.Controller.PrefsUtils;
import com.example.dama.Controller.User;
import com.example.dama.Model.Pawn;
import com.example.dama.Model.Piece;
import com.example.dama.Model.Position;
import android.os.Message;

import java.util.ArrayList;
import java.util.Locale;

public class GameBoard extends AppCompatActivity {
    //private SharedPreferences.Editor editor;
    TextView turnBar, commandBar;
    String p1Name, p2Name;
    int p1Index, p2Index;
    ImageView [][] board;
    User user1 = new User("DEFAULT1", "1234"), user2 = new User("DEFAULT2", "1234");
    ArrayList<User> userArrayList;
    GameManager gm;
    ImageView imgGif;
    int[] animationIdWinner = new int[8];
    int[] animationIdDraw = new int[28];
    MyHandler handler;
    AnimatedGif animation;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.game_board);
        userArrayList = PrefsUtils.readPersonsList(this);
        Bundle extras = getIntent().getExtras();
        p1Index = extras.getInt("index1");
        p2Index = extras.getInt("index2");
        user1 = userArrayList.get(p1Index);
        user2 = userArrayList.get(p2Index);
        p1Name = user1.toString().toUpperCase(Locale.ROOT).concat("'S TURN");
        p2Name = user2.toString().toUpperCase(Locale.ROOT).concat("'S TURN");
        turnBar = findViewById(R.id.tv_playerXturn);
        turnBar.setText(p1Name);
        commandBar = findViewById(R.id.tv_commands);
        commandBar.setText("GameManager");
        this.gm = new GameManager(this);
        this.gm.initGame();
    }

    public TextView getCommandBar() {
        return commandBar;
    }
    public TextView getTurnBar() {
        return turnBar;
    }
    public ImageView[][] getBoard() {
        return board;
    }
    public User getUser1() {
        return user1;
    }
    public User getUser2() {
        return user2;
    }
    public ArrayList<User> getUserArrayList() {
        return userArrayList;
    }

    public void initBoard() {
        int mRows = 8;
        int mCols = 8;
        this.board = new ImageView[mRows][mCols];
        for(int iRow = 0; iRow < mRows; iRow++){
            for (int iCol = 0; iCol < mCols; iCol++){
                  String rowCol = "square_".concat(Integer.toString(iRow).concat(Integer.toString(iCol)));
                  //Log.d("rowCol", rowCol);
                  int resId = getResources().getIdentifier(rowCol, "id", getPackageName());
                  this.board[iRow][iCol] = findViewById(resId);
            }
        }
    }

    public void onClick(View view) {
        int rowcol[] = deconstructTag(view);
        int row = rowcol[0], col = rowcol[1];
        Position clicked = new Position(row, col);
        if(this.gm.getAction() == Action.FirstClick) {
            this.gm.firstClick(clicked);
            return;
        }
        if(this.gm.getAction() == Action.SecondClick) {
            this.gm.secondClick(this.gm.getSelectedPiece(), clicked);
            this.gm.checkWin();
            this.gm.checkDraw();
            if (this.gm.getGameStatus() == GameStatus.WIN || this.gm.getGameStatus() == GameStatus.DRAW) {
                this.showEndGameDialog();
            }
            return;
        }
        return;
    }

    public void markPossiblePositions(@NonNull Position pos) {
        int row = pos.getRow(), col = pos.getCol();
        if(this.gm.getBoard().isCellEmpty(pos)) {
            if (row % 2 == col % 2) {
                this.board[row][col].setBackground(getDrawable(R.drawable.b_optional));
            }
            if (row % 2 != col % 2) {
                this.board[row][col].setBackground(getDrawable(R.drawable.w_optional));
            }
        }
        else {
            if (row % 2 == col % 2) {
                if (this.gm.getBoard().getBoard()[row][col].getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    if (!this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.bwpc));
                    if (this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.bwqc));
                }
                if (this.gm.getBoard().getBoard()[row][col].getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    if (!this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.bbpc));
                    if (this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.bbqc));
                }
            }
            if (row % 2 != col % 2) {
                if (this.gm.getBoard().getBoard()[row][col].getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    if (!this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.wwpc));
                    if (this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.wwqc));
                }
                if (this.gm.getBoard().getBoard()[row][col].getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    if (!this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.wbpc));
                    if (this.gm.getBoard().getBoard()[row][col].isAQueen())
                        this.board[row][col].setBackground(getDrawable(R.drawable.wbqc));
                }
            }
        }
    }

    public void cancelMarking(Position pos) {
        int row = pos.getRow(), col = pos.getCol();
        if(this.gm.getBoard().isCellEmpty(pos)) {
            if (row % 2 == col % 2) {
                this.board[row][col].setBackground(getDrawable(R.drawable.bee));
            }
            if (row % 2 != col % 2) {
                this.board[row][col].setBackground(getDrawable(R.drawable.wee));
            }
        }
        else {
            Piece piece = this.gm.getBoard().getPiece(pos);
            determineDraw(piece, pos);
        }
    }

    public void removePiece(Position position) {
        if (position.getRow() % 2 == position.getCol() % 2)
            this.board[position.getRow()][position.getCol()].setBackground(getDrawable(R.drawable.bee));
        if (position.getRow() % 2 != position.getCol() % 2)
            this.board[position.getRow()][position.getCol()].setBackground(getDrawable(R.drawable.wee));
    }

    public void pieceExecAction(Piece piece, Position to) {
       determineDraw(piece, to);
    }


    public int[] deconstructTag(View view){
        int rowCol[] = new int[2];
        String rc = view.getTag().toString();
        int rcti = Integer.parseInt(rc);
        rowCol[0] = (rcti / 10) % 10;
        rowCol[1] = rcti % 10;
        return rowCol;
    }

    public void makeQueen(Pawn pawn) {
        determineDraw(pawn, pawn.getPosition());
    }

    public void determineDraw(Piece piece, Position position){
        int row = position.getRow(), col = position.getCol();
        if (row % 2 == col % 2) { //brown bg
            if (piece.isAQueen()) {
                if (piece.getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.bwq));
                }
                if (piece.getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.bbq));
                }
            }
            if (!piece.isAQueen()) {
                if (piece.getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.bwp));
                }
                if (piece.getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.bbp));
                }
            }
        }
        if (row % 2 != col % 2) { //white bg
            if (piece.isAQueen()) {
                if (piece.getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.wwq));
                }
                if (piece.getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.wbq));
                }
            }
            if (!piece.isAQueen()) {
                if (piece.getPlayer().getColor().equalsIgnoreCase("WHITE")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.wwp));
                }
                if (piece.getPlayer().getColor().equalsIgnoreCase("BLACK")) {
                    this.board[row][col].setBackground(getDrawable(R.drawable.wbp));
                }
            }
        }
    }

    public void restart() {
        this.gm.initGame();
        this.initBoard();
    }


    //ANIMATION
    private class MyHandler extends Handler
    {
        int[] animationId2;

        public MyHandler(int[] _animationId2)
        {
            animationId2 = _animationId2;

        }

        @Override
        public void handleMessage(Message msg)
        {
            Bundle data = msg.getData();
            int count = data.getInt("index");

            imgGif.setImageResource(animationId2[count]);
            //tvFrame.setText(count + "");
        }
    }


    public class AnimatedGif extends Thread{
        private int i;
        private int length;
        private String prefix;
        boolean stopped=false;

        public AnimatedGif(String prefix, int length)  {
            this.prefix = prefix;
            this.length = length;
            this.i = 0;
            initAnimationWinner();
        }
        public void setStopped(boolean stopped){
            this.stopped = stopped;
        }

        public void run()  {

            while (!stopped)   {
                i++;
                if(i == length)
                    i = 0;
                try {
                    Thread.sleep(100);
                } catch (InterruptedException ex)  {
                    ex.printStackTrace();
                }
                sendCounter2Activity(i);
            }
        }
        private void sendCounter2Activity(int index)
        {
            Message msg = handler.obtainMessage();
            Bundle data = msg.getData();
            data.putInt("index", index);
            handler.sendMessage(msg);
        }

        public void initAnimationWinner() {
            String name;
            for (int i = 0; i < length; i++) {
                Log.d("name", "" + this.length + animationIdDraw.length);
                name = prefix + "" + i;

                if (this.length == animationIdDraw.length)
                    animationIdDraw[i] = string2drawableId(name);
                else
                    animationIdWinner[i] = string2drawableId(name);

            }
        }
    }

    public int string2drawableId(String drawableName)
    {
        int drawableId = GameBoard.this.getResources().getIdentifier(drawableName, "drawable", GameBoard.this.getPackageName());
        return drawableId;
    }


    public void showEndGameDialog()
    {
        final Dialog dialog = new Dialog(this);
        dialog.setContentView(R.layout.end_game_dialog);
        Button btnRestart = dialog.findViewById(R.id.btn_restart);
        TextView tv_End_Game = dialog.findViewById(R.id.end_game_name);
        imgGif = dialog.findViewById(R.id.winner_gif_0);
        
        CustomDialogClickListener dcl = new CustomDialogClickListener(dialog);
        btnRestart.setOnClickListener(dcl);

        if(this.gm.getGameStatus() == GameStatus.DRAW){
            tv_End_Game.setText("IT'S DRAW!!!!");
            animation = new AnimatedGif("draw_gif_", 28);
            handler = new MyHandler(animationIdDraw);
            }

        if (this.gm.getGameStatus() == GameStatus.WIN) {
            tv_End_Game.setText(gm.checkWin().getUser().getName().concat(" WON!!!"));
            animation = new AnimatedGif("winner_gif_", 8);
            handler = new MyHandler(animationIdWinner);
        }
        animation.start();
        dialog.show();
    }

    private class CustomDialogClickListener implements View.OnClickListener
    {
        Dialog dialog;

        public CustomDialogClickListener(Dialog _dialog)
        {
            this.dialog = _dialog;
        }

        @Override
        public void onClick(View v) {
            animation.setStopped(true);
            dialog.dismiss();
            //GameBoard.this.restart();
            //GameBoard.this.startActivity(new Intent(GameBoard.this, GameBoard.class));
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (MenuUtils.handleMenu(item, this))
            return true;
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.menu, menu);
        return true;
    }

}