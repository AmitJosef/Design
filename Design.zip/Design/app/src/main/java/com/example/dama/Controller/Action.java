package com.example.dama.Controller;

public enum Action {
    FirstClick,
    SecondClick;
}
