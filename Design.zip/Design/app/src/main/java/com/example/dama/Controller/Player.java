package com.example.dama.Controller;

public class Player {
    private User user;
    private String color;

    public Player(User user, String color){
        this.user = user;
        this.color = color;
    }

    public User getUser() {
        return user;
    }

    public String getColor() {
        return color;
    }
}
