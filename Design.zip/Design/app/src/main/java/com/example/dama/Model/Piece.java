package com.example.dama.Model;

import com.example.dama.Controller.Player;

public abstract class Piece {
    private Player player;
    private Position position;

    public Piece(Player player, Position position){
        this.player = player;
        this.position = position;
    }

    public Piece(Piece piece) {
        this.player = piece.getPlayer();
        this.position = piece.getPosition();
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Player getPlayer() {
        return player;
    }

    public abstract boolean isAQueen();
    public abstract void execMove(Position to);

    @Override
    public String toString() {
        return "Piece{" +
                "player=" + player +
                ", position=" + position.toString() +
                ", isAQueen= " + this.isAQueen() +
                '}';
    }
}
