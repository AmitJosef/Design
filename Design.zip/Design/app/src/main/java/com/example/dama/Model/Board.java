package com.example.dama.Model;

import androidx.annotation.NonNull;

import com.example.dama.Controller.Player;
import com.example.dama.Controller.User;

import java.util.ArrayList;

public class Board {
    private Piece[][] board = new Piece[8][8];
    private int remainingPieces[] = {16, 16}; //index 0 -> p1, index 1 -> p2
    private Player[] players = new Player[2];//index 0 -> p1, index 2 ->p2
    private int turn; // 0 -> p1 / 1 -> p2

    public Board(){
        this.players[0] = new Player(new User("a", "a"), "white");
        this.players[1] = new Player(new User("b", "b"), "black");
        this.turn = 0;
        for (int row = 1; row <= 2; row++){
            for (int col = 0; col < 8; col++){
                this.board[row][col] = new Pawn(players[1], new Position(row, col));
            }
        }
        for (int row = 5; row <= 6; row++){
            for (int col = 0; col < 8; col++){
                this.board[row][col] = new Pawn(players[0], new Position(row, col));
            }
        }

    }

    public Piece[][] getBoard() {
        return board;
    }

    public void setPlayers(Player[] players) {
        this.players = players;
    }

    public int getTurn() {
        return turn;
    }
    public void changeTurn() {
        if (turn == 0) {
            turn = 1;
            return;
        }
        else
            turn = 0;
        return;
    }

    public int getCurrPlayerRemainingPieces() {
        return remainingPieces[turn];
    }

    public int winner(){
        if (remainingPieces[0] == 0)
                return 1;
        else if (remainingPieces[1] == 0)
                return 0;
        else
            return -1; //no win
    }

    public boolean checkDraw(){
        if (remainingPieces[0] == remainingPieces[1] && remainingPieces[0] == 1) {
            return true;
        }
        return false;
    }

    //if there eats return those, else return any other moves
    public ArrayList<Position> legalPositions(@NonNull Piece selected){
        ArrayList<Position> positions = new ArrayList<Position>();
        positions = (this.legalEats2(selected)[1].isEmpty() ? this.legalMoves(selected) : this.legalEats2(selected)[1]);
        return positions;
    }
    //in game manager check if piece in given position isSelectable and if so, use legalPositions with selected piece as param

    public ArrayList<Position> legalMoves(@NonNull Piece selected){
        ArrayList<Position> temp = new ArrayList<Position>();
        ArrayList<Position> positions = new ArrayList<Position>();

        if(selected instanceof Pawn) {
            if (selected.getPlayer().getColor().equalsIgnoreCase("white")) {
                if (isCellEmpty(new Position(selected.getPosition().getRow() - 1, selected.getPosition().getCol()))) {
                    temp.add(new Position(selected.getPosition().getRow() - 1, selected.getPosition().getCol()));
                    //Log.d("pos", new Position(selected.getPosition().getRow() + 1, selected.getPosition().getCol()).toString());
                }
            }
            else if (selected.getPlayer().getColor().equalsIgnoreCase("black")) {
                if (isCellEmpty(new Position(selected.getPosition().getRow() + 1, selected.getPosition().getCol()))) {
                    temp.add(new Position(selected.getPosition().getRow() + 1, selected.getPosition().getCol()));
                }
            }

            if (isCellEmpty(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 1))){
                temp.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 1));
                //Log.d("pos", new Position(selected.getPosition().getRow(), selected.getPosition().getCol()).toString() + 1);
            }
            if (isCellEmpty(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 1))){
                temp.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 1));
                //Log.d("pos", new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 1).toString());
            }
        }

        else if (selected instanceof Queen) {
            int row = selected.getPosition().getRow();
            int col = selected.getPosition().getCol();
            int up = row + 1, down = row - 1, right = col + 1, left = col -1;
            while (up <= 7 && this.isCellEmpty(new Position(up, col))) {
                temp.add(new Position(up, col));
                up++;
            }
            while (down >= 0 && this.isCellEmpty(new Position(down, col))) {
                temp.add(new Position(down, col));
                down--;
            }
            while (right <= 7 && this.isCellEmpty(new Position(row, right))) {
                temp.add(new Position(row, right));
                right++;
            }
            while (left >= 0 && this.isCellEmpty(new Position(row, left))) {
                temp.add(new Position(row, left));
                left--;
            }
        }

        for (int i = 0; i < temp.size(); i++){
            if (temp.get(i).getRow() <= 7 && temp.get(i).getRow() >= 0 && temp.get(i).getCol() <= 7 && temp.get(i).getCol() >= 0) {
                positions.add(temp.get(i));
            }
        }
        return positions;
    }

    public ArrayList<Position>[] legalEats2(@NonNull Piece selected){
        ArrayList<Position>[] e_m = new ArrayList[2];
        ArrayList<Position> tempE= new ArrayList<Position>();
        ArrayList<Position> tempM= new ArrayList<Position>();
        ArrayList<Position> eatenPositions = new ArrayList<Position>();
        ArrayList<Position> movePositions = new ArrayList<Position>();

        if(selected instanceof Pawn) {
            if (selected.getPlayer().getColor().equalsIgnoreCase("white")) {
                if ((isCellEmpty(new Position(selected.getPosition().getRow() - 2, selected.getPosition().getCol())) && areRivals(selected, new Position(selected.getPosition().getRow() - 1, selected.getPosition().getCol())))){
                    tempE.add(new Position(selected.getPosition().getRow() - 1, selected.getPosition().getCol()));
                    tempM.add(new Position(selected.getPosition().getRow() - 2, selected.getPosition().getCol()));
                }
            }
            else if (selected.getPlayer().getColor().equalsIgnoreCase("black")) {
                if ((isCellEmpty(new Position(selected.getPosition().getRow() + 2, selected.getPosition().getCol())) && areRivals(selected, new Position(selected.getPosition().getRow() + 1, selected.getPosition().getCol())))){
                    tempE.add(new Position(selected.getPosition().getRow() + 1, selected.getPosition().getCol()));
                    tempM.add(new Position(selected.getPosition().getRow() + 2, selected.getPosition().getCol()));
                }
            }
            if((isCellEmpty(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 2)) && areRivals(selected, new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 1)))) {
                tempE.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 1));
                tempM.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() + 2));
            }
            if((isCellEmpty(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 2)) && areRivals(selected, new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 1)))) {
                tempE.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 1));
                tempM.add(new Position(selected.getPosition().getRow(), selected.getPosition().getCol() - 2));
            }
        }

        else if (selected instanceof Queen) {
            int row = selected.getPosition().getRow();
            int col = selected.getPosition().getCol();
            int up = row + 1, down = row - 1, right = col + 1, left = col -1;
            boolean firstEat = false;
            while (up <= 7) {
                if(areRivals(selected, new Position(up, col)) && isCellEmpty(new Position(up + 1, col)) && !firstEat) {
                    tempE.add(new Position(up, col)); //adds position of eaten piece, needs to move to position in isCellEmpty (+1/-1)
                    tempM.add(new Position(up + 1, col));
                    firstEat = true;
                    up++;
                    continue;
                }
                else if(!this.isCellEmpty(new Position(up, col)) && !this.isCellEmpty(new Position(up + 1, col))) {
                    break;
                }
                else if (firstEat && isCellEmpty(new Position(up, col))) {
                    tempM.add(new Position(up, col));
                }
                else if (firstEat && !isCellEmpty(new Position(up, col))) {
                    break;
                }
                up++;
            }
            firstEat = false;

            while (down >= 0) {

                if(areRivals(selected, new Position(down, col)) && isCellEmpty(new Position(down - 1, col)) && !firstEat) {
                    tempE.add(new Position(down, col));
                    firstEat = true;
                    down--;
                    continue;
                }
                else if(!this.isCellEmpty(new Position(down, col)) && !this.isCellEmpty(new Position(down - 1, col))) {
                    break;
                }
                if (firstEat && isCellEmpty(new Position(down, col))) {
                    tempM.add(new Position(down, col));
                }
                else if (firstEat && !isCellEmpty(new Position(down, col))) {
                    break;
                }
                down--;
            }

            firstEat = false;

            while (right <= 7) {

                if(areRivals(selected, new Position(row, right)) && isCellEmpty(new Position(row, right + 1)) && !firstEat) {
                    tempE.add(new Position(row, right));
                    firstEat = true;
                    right++;
                    continue;
                }
                else if(!this.isCellEmpty(new Position(row, right)) && !this.isCellEmpty(new Position(row, right + 1))) {
                    break;
                }
                if (firstEat && isCellEmpty(new Position(row, right))) {
                    tempM.add(new Position(row, right));
                }
                else if (firstEat && !isCellEmpty(new Position(row, right))) {
                    break;
                }
                right++;
            }

            firstEat = false;
            while (left >= 0) {
                if(areRivals(selected, new Position(row, left)) && isCellEmpty(new Position(row, left - 1)) && !firstEat) {
                    tempE.add(new Position(row, left));
                    firstEat = true;
                    left--;
                    continue;
                }
                else if(!this.isCellEmpty(new Position(row, left)) && !this.isCellEmpty(new Position(row, left - 1))) {
                    break;
                }
                if (firstEat && isCellEmpty(new Position(row, left))) {
                    tempM.add(new Position(row, left));
                }
                else if (firstEat && !isCellEmpty(new Position(row, left))) {
                    break;
                }
                left--;
            }
        }
        for (int i = 0; i < tempE.size(); i++){
            if (tempE.get(i).getRow() <= 7 && tempE.get(i).getRow() >= 0 && tempE.get(i).getCol() <= 7 && tempE.get(i).getCol() >= 0) {
                eatenPositions.add(tempE.get(i));
            }
        }
        for (int i = 0; i < tempM.size(); i++){
            if (tempM.get(i).getRow() <= 7 && tempM.get(i).getRow() >= 0 && tempM.get(i).getCol() <= 7 && tempM.get(i).getCol() >= 0) {
                movePositions.add(tempM.get(i));
            }
        }
        e_m[0] = eatenPositions;
        e_m[1] = movePositions;
        return e_m;
    }

    public void makeQueen(@NonNull Pawn pawn, Position position){
        this.board[position.getRow()][position.getCol()] = new Queen(pawn);
        //Log.d("print",this.board[position.getRow()][position.getCol()].toString());
    }

    public void removePiece(@NonNull Piece piece){
        this.board[piece.getPosition().getRow()][piece.getPosition().getCol()] = null;
        if (piece.getPlayer() == this.players[0])
            this.remainingPieces[0]--;
        else if (piece.getPlayer() == this.players[1])
            this.remainingPieces[1]--;
        piece = null;
    }

    public Piece getPiece(@NonNull Position position){
        return this.board[position.getRow()][position.getCol()];
    }

    public boolean isPieceSelectable(@NonNull Piece piece){
        if (piece == null) {return false;}
        if ((piece.getPlayer().getColor() == this.players[turn].getColor()) && (canEat(piece) || (noneCanEat() && canMove(piece)))) {
            return true;
        }
        return false;
    }

    public boolean noneCanEat(){
        for (Piece pArray[] : this.board) {
            for (Piece piece : pArray) {
                if ((piece != null) && (piece.getPlayer() == this.players[turn] && canEat(piece))){
                    return false;
                }
            }
        }
        return true;
    }

    public boolean noneCanMove(){
        for (Piece pArray[] : this.board) {
            for (Piece piece : pArray) {
                if ((piece != null) && (piece.getPlayer() == this.players[turn] && canMove(piece))){
                    return false;
                }
            }
        }
        return true;
    }

    private boolean areRivals(Piece selected, Position position){
        if (this.isCellEmpty(position)) {
            return false;
        }
        if(selected.getPlayer() != this.getPiece(position).getPlayer())
            return true;
        return false;
    }

    public boolean isCellEmpty(@NonNull Position position){
        if (position.getRow() > 7 || position.getCol() > 7 || position.getRow() < 0 || position.getCol() < 0) {
            return false;
        }
        if (this.board[position.getRow()][position.getCol()] == null) {
            return true;
        }
        return false;
    }


    private boolean canMove(@NonNull Piece selected){
        return !(this.legalMoves(selected).isEmpty());
    }

    private boolean canEat(@NonNull Piece selected){
        return !(this.legalEats2(selected)[0].isEmpty());
    }

}
