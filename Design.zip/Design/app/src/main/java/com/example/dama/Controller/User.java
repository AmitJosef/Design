package com.example.dama.Controller;

import android.util.Log;

public class User {
        private String name;
        private String password;
        private int games;
        private int wins;
        private int losses;
        private int draws;
        private float winsPercent;

        public User(String name, String password) {
            this.name = name;
            this.password = password;
            this.games = 0;
            this.wins = 0;
            this.losses = 0;
            this.draws = 0;
            this.winsPercent = 0;
        }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public int getWins() {
        return wins;
    }

    public int getGames() {
        return games;
    }

    public void setWinsPercent(float winsPercent) {
        this.winsPercent = winsPercent;
    }

    public void addGame() {
            this.games++;
    }
    public void addWin() {
            this.wins++;
            this.winsPercent = calcWinsPercent();
    }
    public void addLose() {
            this.losses++;
            this.winsPercent = calcWinsPercent();
    }
    public void addDraw() {
        this.draws++;
        this.winsPercent = calcWinsPercent();
    }

    public float getWinsPercent() {
        return winsPercent;
    }


    public float calcWinsPercent() {
            float wins = this.wins, games = this.games;
            return (wins / games) * 100;
    }

    @Override
    public String toString() {
        return this.name;
    }

    public String showAllStats() {
        return this.name + ": WINS: " + this.wins + ", LOSSES: " + this.losses + ", DRAWS: " + this.draws + ", WINS%: " + this.winsPercent ;
    }
}

